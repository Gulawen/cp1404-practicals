def max():
    fn = int(input("pls enter the first number"))
    sn = int(input("pls enter the second number"))
    if fn > sn:
        print(str(fn))
    else:
        print(str(sn))
max()