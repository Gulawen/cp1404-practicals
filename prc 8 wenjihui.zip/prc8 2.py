def fallingDistance():
    for i in range(10):
        t = i +1
        g = 9.8
        d = 1/2*g*t**2
        print("the distance is %.2f" %d)
fallingDistance()

