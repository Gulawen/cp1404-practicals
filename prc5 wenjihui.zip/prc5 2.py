def main():
    counter = 1
    TIME_LIMIT = 60
    while counter < TIME_LIMIT:
        print(counter)
        counter = counter + 1
    print("Time's up!")
main()